const router = require('express').Router()
const staticController=require('../Controller/staticController')
/**
* @swagger
* /static/listStatic:
*   get:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: page
*         description: enter page no .
*         in: query
*         required: false
*       - name: limit
*         description: enter limit .
*         in: query
*         required: false
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/
 router.get('/listStatic',staticController.listStatic);
 /**
* @swagger
* /static/viewStatic:
*   get:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: type
*         description: enter page no .
*         in: query
*         required: true
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/
router.get('/viewStatic',staticController.viewStatic);
/**
* @swagger
* /static/editStatic:
*   put:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: _id
*         description: enter _id .
*         in: query
*         required: true
*       - name: type
*         description: enter type .
*         in: formData
*         required: false
*       - name: title
*         description: enter title .
*         in: formData
*         required: false
*       - name: description
*         description: enter description .
*         in: formData
*         required: false
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/
router.put('/editStatic',staticController.editStatic);
// router.get('/viewUser/:_id',staticController.viewUser);

 
module.exports=router