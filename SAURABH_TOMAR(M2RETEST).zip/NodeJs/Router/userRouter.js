const userRouter = require('express').Router();
// const { upload, multiFiles } = require('../Controller/userController');
const userController = require('../Controller/userController');
const orderController = require('../Controller/orderController');

const adminController = require('../Controller/adminController');
const machineController = require('../Controller/machineController');


const { UploadImage } = require('../helper/commonFunction');
const auth = require('../middleware/auth')
const multer =require('multer')
const upload = multer({dest: 'uploads'})
//USER CONTROLLER

/**
* @swagger
* /user/signUp:
*   post:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: email
*         description: email is required.
*         in: formData
*         required: true
*       - name: password
*         description: password is required.
*         in: formData
*         required: true
*       - name: confirmPassword
*         description: confirmPassword is required.
*         in: formData
*         required: true
*       - name: mobileNumber
*         description: mobileNumber is required.
*         in: formData
*         required: false
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/

userRouter.post('/signUp',userController.signUp);
/**
* @swagger
* /user/otpVerify:
*   put:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: email
*         description: email is required.
*         in: formData
*         required: true
*       - name: otp
*         description: otp is required.
*         in: formData
*         required: true
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/

userRouter.put('/otpVerify', userController.otpVerify);

/**
* @swagger
* /user/resendOtp:
*   put:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: email
*         description: email is required.
*         in: formData
*         required: true
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/
userRouter.put("/resendOtp", userController.resendOTP);
/**
* @swagger
* /user/login:
*   put:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: email
*         description: email is required.
*         in: formData
*         required: true
*       - name: password
*         description: password is required.
*         in: formData
*         required: true
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/

userRouter.put("/login", userController.login);
/**
* @swagger
* /user/getProfile:
*   get:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: _id
*         description: id is required.
*         in: raw
*         required: true
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/
userRouter.get("/getProfile",userController.getProfile);
/**
* @swagger
* /user/forgotPassword:
*   put:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: email
*         description: email is required.
*         in: formData
*         required: true
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/

userRouter.put("/forgotPassword", userController.forgotPassword);


userRouter.put("/editProfile",auth.jwtToken,userController.editProfile);
/**
* @swagger
* /user/resetPassword:
*   put:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: email
*         description: email is required.
*         in: formData
*         required: true
*       - name: otp
*         description: otp is required.
*         in: formData
*         required: true
*       - name: newPassword
*         description: newPassword is required.
*         in: formData
*         required: true
*       - name: confirmNewPassword
*         description: confirmNewPassword is required.
*         in: formData
*         required: true
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/


userRouter.put("/resetPassword", userController.resetPassword);
/**
* @swagger
* /user/changePassword:
*   put:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: email
*         description: email is required.
*         in: formData
*         required: true
*       - name: password
*         description: password is required.
*         in: formData
*         required: true
*       - name: newPassword
*         description: newPassword is required.
*         in: formData
*         required: true
*       - name: confirmNewPassword
*         description: confirmNewPassword is required.
*         in: formData
*         required: true
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/


userRouter.put("/changePassword",userController.changePassword);
/**
* @swagger
* /user/allRecords:
*   get:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: document
*         description: enter document .
*         in: formData
*         required: true
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/

userRouter.get("/allRecords", userController.allRecords);
/**
* @swagger
* /user/showResult:
*   get:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: search
*         description: enter document .
*         in: query
*         required: true
*       - name: page
*         description: enter page no .
*         in: query
*         required: false
*       - name: limit
*         description: enter limit .
*         in: query
*         required: false
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/

userRouter.get("/showResult", userController.showResult);
//userRouter.get("/qrCode", userController.qrCode);
/**
* @swagger
* /user/viewUser2:
*   get:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: fromDate
*         description: enter date .
*         in: query
*         required: false
*       - name: toDate
*         description: enter date .
*         in: query
*         required: false

*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/


userRouter.get('/viewUser2',userController.viewUser2)
 userRouter.post('/upload',userController.upload);
// userRouter.post('/multiFiles', upload.array('image,15'),userController.multiFiles);

//ADMIN CONTROLLER
/**
* @swagger
* /admin/otpVerify1:
*   put:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: email
*         description: email is required.
*         in: formData
*         required: true
*       - name: otp
*         description: otp is required.
*         in: formData
*         required: true
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/

userRouter.put('/otpVerify1', adminController.adminOtpVerify);
/**
* @swagger
* /admin/resendOtp1:
*   put:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: email
*         description: email is required.
*         in: formData
*         required: true
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/

userRouter.put("/resendOtp1", adminController.adminResendOTP);
/**
* @swagger
* /admin/login1:
*   put:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: email
*         description: email is required.
*         in: formData
*         required: true
*       - name: password
*         description: password is required.
*         in: formData
*         required: true
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/

userRouter.put("/login1", adminController.adminLogin);
/**
* @swagger
* /admin/adminGetProfile:
*   get:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: _id
*         description: id is required.
*         in: raw
*         required: true
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/
userRouter.get("/adminGetProfile",adminController.adminGetProfile);
/**
* @swagger
* /admin/forgotPassword1:
*   put:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: email
*         description: email is required.
*         in: formData
*         required: true
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/

userRouter.put("/forgotPassword1", adminController.adminForgotPassword);

userRouter.put("/adminEditProfile",adminController.adminEditProfile);
/**
* @swagger
* /admin/resetPassword1:
*   put:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: email
*         description: email is required.
*         in: formData
*         required: true
*       - name: otp
*         description: otp is required.
*         in: formData
*         required: true
*       - name: newPassword
*         description: newPassword is required.
*         in: formData
*         required: true
*       - name: confirmNewPassword
*         description: confirmNewPassword is required.
*         in: formData
*         required: true
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/
userRouter.put("/resetPassword1", adminController.adminResetPassword);
/**
* @swagger
* /admin/changePassword1:
*   put:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: email
*         description: email is required.
*         in: formData
*         required: true
*       - name: password
*         description: password is required.
*         in: formData
*         required: true
*       - name: newPassword
*         description: newPassword is required.
*         in: formData
*         required: true
*       - name: confirmNewPassword
*         description: confirmNewPassword is required.
*         in: formData
*         required: true
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/
userRouter.put("/changePassword1",adminController.adminChangePassword);



//machine controller
/**
* @swagger
* /machine/machine:
*   post:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: machineName
*         description: machineName is required.
*         in: formData
*         required: true
*       - name: image
*         description: images is required.
*         in: formData
*         Content-Type: image/png
*         type: file
*         required: true
*       - name: capacity
*         description: enter machine capacity.
*         in: formData
*         required: false
*       - name: type
*         description: type of machine.
*         in: formData
*         required: false
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/


userRouter.post('/machine',upload.array('image',15),machineController.machineAdmin); 
/**
* @swagger
* /machine/editMachine:
*   put:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: _id
*         description: _id is required.
*         in: formData
*         required: true
*       - name: capacity
*         description: enter machine capacity.
*         in: formData
*         required: false
*       - name: type
*         description: type of machine.
*         in: formData
*         required: false
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/

userRouter.put('/editMachine',machineController.editMachine);
/**
* @swagger
* /machine/deleteMachine:
*   delete:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: machineName
*         description: machineName is required.
*         in: formData
*         required: true
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/

userRouter.delete('/deleteMachine',machineController.deleteMachine); 
/**
* @swagger
* /machine/machineList:
*   get:
*     tags:
*       - USER MANAGEMENT
*     description: Creating Docs for USER
*     produces:
*       - application/json
*     parameters:
*       - name: machineName
*         description: machineName is required.
*         in: query
*         required: false
*     responses:
*       200:
*         description: Done successfully.
*       404:
*         description: DATA NOT FOUND.
*       500:
*         description: Internal server error.
*/
userRouter.get("/machineList",machineController.machineList);




  
//order Controller
userRouter.post('/orderSummary', orderController.orderSummary); 
userRouter.put('/updateQuantity', orderController.updateQuantity);


module.exports = userRouter;
