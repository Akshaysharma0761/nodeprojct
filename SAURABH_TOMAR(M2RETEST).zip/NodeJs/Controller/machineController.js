const machineModel = require('../Model/machineModel')
const qrCodeGenerate2 = require('qrcode')
const auth = require('../middleware/auth')
const commonFunction = require('../helper/commonFunction')

module.exports={
    machineAdmin:async(req,res)=>{
        try{
            const data1 = await machineModel.findOne({
                $and: [{
                     $or: [
                        {machineName: req.body.machineName }
                      ]},{userType:"ADMIN"},
                { status: { $ne: "DELETE" }} ]
            })
        
            if(data1)
            {
                res.send({responseCode:409,responseMessage:'machine Already exist',responseResult:[]})  
            }
             else{
                req.body.machineName=req.body.machineName
               req.body.serialNumber=await commonFunction.generateSerial(await machineModel.count())
                let image=[];
            
                for (let index=0;index<req.files.length;index++)
                {
                    let files = await commonFunction.UploadImage(req.files[index].path);
                    image.push(files)
                }
               req.body.images=image
            let data=req.body
             let stringData= JSON.stringify(data)
            let qr= await qrCodeGenerate2.toDataURL(stringData);
            let qrCodes= await commonFunction.UploadImage(qr)
            let url;
             req.body.url=qrCodes
                let machineInfo= await machineModel(req.body).save();  
                res.send({responseCode:200,responseMessage:'successfully machine genrated',responseResult:url,machineInfo})
            }
            
        }
        catch(error)
        { 
            console.log(error)
            res.send({responseCode:500,responseMessage:'Something went wrong',responseResult:[]})
        }
    },
    editMachine: async (req, res) => {
        try { 
            let query = {_id:req.body._id ,status: 'ACTIVE', userType: "ADMIN" };
            let user = await machineModel.findOne(query);
         
            if (!user) {
                return res.send({ reponseCode: 404, responseMessage: 'Data  not found .', responseResult: [] });
            } else {
                let query = { $and: [ {_id:req.body._id } , { status: { $ne: "DELETE" } }, { userType: 'ADMIN' }] };
                let userCheck = await machineModel.findOne(query);
                if (userCheck) {
                  
                     let updateMachine = await machineModel.findByIdAndUpdate({ _id:req.body._id }, { $set:req.body }, { new:true })
                    if (updateMachine) {
                        return res.send({ reponseCode: 200, responseMessage: 'Succesfully updated', responseResult: updateMachine }); 
                    }
                }
                else {
                    if (req.body.machineName == userCheck.machineName) {
                        return res.send({ reponseCode: 409, responseMessage: 'Machine already in use.', responseResult: [] });
                    }
                }
            }
        } catch (error) {
           
            return res.send({ reponseCode: 501, responseMessage: 'Something went wrong', responseResult: error.message });
            // return res.send(responseCode = 500, responseMessage = "Something went wrong", result = [])
        }
    },
    deleteMachine: async (req, res) => {
        try {
            let query = { $and: [{machineName:req.body.machineName }, { status: { $ne: "DELETE" } }, { userType: "ADMIN" }], };
            const userResult = await machineModel.findOne(query)
            if (!userResult) {
                return res.send({ reponseCode: 404, responseMessage: 'Data not found .', responseResult:[], });
            }
            else {
            let userResult1 = await machineModel.deleteOne(query)
                return res.send({ reponseCode: 200, responseMessage: 'Machine deleted successfully.', responseResult:userResult1});
        
         }
        
        } catch (error) {
            console.log(error)
            return res.send({ responseCode: 501, responseMessage: "Something went wrong!", responseResult: error.message });
        }


    },
    machineList:async(req,res)=>
    {
     
            try {
                var query={status:{$ne:'DELETE'},userType:'ADMIN'};
                if(req.query.search)
                {
                    query.$or=[
                        {machineName:{$regex:req.query.search}},
                        {serialNumber:{$regex:req.query.search,$options:'i'}},
                    ]
                }
                let options={
                    page:parseInt(req.query.page) ||1,
                    limit:parseInt(req.query.limit) ||10,
                    sort:{createdAt:-1},
                    // populate: 'addressId'
    
    
                }
                let userData=await machineModel.paginate(query,options);
                if(userData.docs.length==0)
                {
                    res.send({responseCode:404, responsemessage:'Data Not found',result:[]})
                }
                else{
    
                    res.send({responseCode:200, responsemessage:'Data found successfully',result:userData})
                }
    
    
            } catch (error) {
                console.log(error)
                return res.send({reponseCode:500,responseMessage:'Something went wrong.',responseResult:[],});
                
            }
    
    },
    

}