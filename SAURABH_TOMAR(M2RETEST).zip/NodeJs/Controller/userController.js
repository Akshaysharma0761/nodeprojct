//const req = require('express/lib/request')

const userModel = require('../Model/userModel')
const addressModel = require('../Model/addressModel')
const commonFunction = require("../helper/commonFunction")
const auth = require('../middleware/auth')
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken')
const qrCodeGenerate = require('qrcode')
const multer  = require('multer')                               
const upload = multer({ dest: 'uploads/' })

const { response } = require('express');
//const req = require('express/lib/request');
module.exports = {
    signUp:async(req, res)=>
    {
        try
        {
            let result = await userModel.findOne({$and:[{$or:[{email:req.body.email},]},{status:{$ne:"DELETE"}},{userType:'USER'}],},)
            if (result) {
                if(result.email == req.body.email){
                    res.send({reponseCode:401,responseMessage:'User already exist',})
                }
           
            }
                else
                {
                    req.body.otp = commonFunction.generateOTP();
                    req.body.otpExpireTime=Date.now()+5*60*1000;
                    let password = req.body.password;
                    let conpass  = req.body.confirmPassword
                    if(password!=conpass)
                    {
                        res.send({reponseCode:401,responseMessage:'password do not match.'})
                    }
                    else{
                        req.body.password=bcrypt.hashSync(password)
                    let subject = 'signUP OTP';
                    let text = `Your OTP : ${req.body.otp}`;
                    let mail = await commonFunction.sendMail(req.body.email,subject,text,)
                    if(!mail){
                        return res.send({reponseCode:500,responseMessage:'Internal server error.2',result:[],})
                    }
                    else{   
                       let userSave = await  new userModel(req.body).save()
                            if (!userSave) {
                                return res.send({reponseCode:500,responseMessage:'Internal server error.3',result:[],})
                            } else {
                                req.body.userId=userSave._id;
                                let saveAddress = await new addressModel(req.body).save();
                                if(!saveAddress){

                                }else{
                                let updateUser = await userModel.findByIdAndUpdate({_id:userSave._id},{$set:{addressId:saveAddress._id,otp:req.body.otp}},{new:true})
                                if (!updateUser) {
                                return res.send({reponseCode:500,responseMessage:'Internal server error.1',result:[],})

                                } else {
                                return res.send({reponseCode:200,responseMessage:'Signup successfully',result:updateUser,saveAddress})                          
                                   }
                                }
                            }
                        }
                    }
                }
        }
        catch(error)
        {
            return res.send({reponseCode:501,responseMessage:'Something went worng',result:error.message})
        }
    },     
    otpVerify: async (req, res) => {
        try {
            const dataUser = await userModel.findOne({
                $and: [{ $or: [{ email: req.body.email }] },
                { status: { $ne: "DELETE" } }]
            })
            if (!dataUser) {
                return res.send({ responseCode: 501, responseMessage: "Something went wrong", result: [] })
            }
            else {
                console.log(dataUser)
                if (dataUser.otpVerify == true) {
                    return res.send({ responseCode: 200, responseMessage: "Otp verified successfully! ", result: dataUser })
                }
                else {
                    let currentTime = Date.now();
                    if (req.body.otp == dataUser.otp) {
                        console.log('57 ==>', dataUser, currentTime)
                        if (dataUser.otpExpireTime >= currentTime) {
                            let userVerify = await userModel.findByIdAndUpdate({ _id: dataUser._id }, { $set: { otpVerify: true } }, { new: true },)
                            if (userVerify) {
                                return res.send({ responseCode: 200, responseMessage: "Otp is verify", responseResult: dataUser })
                            }
                        }
                        else {
                            return res.send({ responseCode: 401, responseMessage: 'Otp time expire ', responseResult: [] })
                        }
                    }
                    else {
                        return res.send({ responseCode: 400, responseMessage: 'Wrong Otp ', responseResult: [] })
                    }
                }
            }
        }
        catch (error) {
            return res.send({ responseCode: 501, responseMessage: "Something went wrong", result: error.message })
        }
    },

    resendOTP: async (req, res) => {
        try {
            let query = {
                $and: [
                    {
                        $or: [
                            { email: req.body.email },
                           // {mobileNo:req.body.mobileNo}
                        ],
                    },
                    { status: { $ne: "DELETE" } },
                ],
            };
            let userResult = await userModel.findOne(query);
            if (!userResult) {
                return res.send({
                    responseCode: 404,
                    responseMessage: "User not found",
                    responseResult: [],

                });
            }
            else {
                let otp = commonFunction.generateOTP();
                let expireTime = Date.now() + 5 * 60 * 1000;
                let subject = 'Otp for Verify';
                let text = `${otp}`;
                let mailResult = await commonFunction.sendMail(userResult.email, subject, text);
                if (mailResult) {
                    let updateUser = await userModel.findByIdAndUpdate({ _id: userResult._id }, { $set: { otpVerify: false, otp: otp, otpExpireTime: expireTime } }, { new: true })
                    if (updateUser) {
                        return res.send({
                            responseCode: 200,
                            responseMessage: "OTP sent successfully",
                            responseResult: updateUser,
                        })
                    }
                }
            }
        }
        catch (error) {
            console.log('114 ==>', error)
            return res.send({ responseCode: 501, responseMessage: 'something went wrong.', responseResult: error.message })

        }
    },
    login: async (req, res) => {
        try {
            const userId = await userModel.findOne({
                $and: [{
                     $or: [
                        { email: req.body.email },
                       // { mobileNumber: req.body.userId },
                      ], userType:"USER"
           
                },
                { status: { $ne: "DELETE" } }]
            })

            if (!userId) {
                return res.send({ responseCode: 404, responseMessage: "User not found", result: [] })
            }
            else {
                if (userId.otpVerify == false) {
                    return res.send({ responseCode: 500, responseMessage: "User not verified", result: [] })
                } else {
                  
                    if (req.body.email != userId.email) {
                        return res.send({ responseCode: 401, responseMessage: "Incorrect email id", result: [] })
                    }
                    else {
                        let passCheck = bcrypt.compareSync(req.body.password, userId.password);
                        if (passCheck == false) {
                            return res.send({ responseCode: 500, responseMessage: "Incorrect password", result: [] })
                        }
                        else {
                            let data = {
                                userId:userId._id,
                                email:userId.email
                              }
                              let token = jwt.sign(data,'test',{expiresIn:'1h'})                   
                            return res.send({ responseCode: 200, responseMessage: "login successfully", result:token })
                        }
                    }
                }
            }
        }
        catch (error) {
            console.log('161 ==>', error)
            return res.send({ responseCode: 501, responseMessage: "Something went wrong", result: error.message })
        }
    },
    getProfile: async (req, res) => {
        try {
            let query = { $and: [{_id:req.body._id }, { status: { $ne: "DELETE" } }, { userType: "USER" }], };
            let userResult = await userModel.findOne(query)
            if (!userResult) {
                return res.send({ reponseCode: 404, responseMessage: 'User not found .', responseResult:[], });
            }
            else {
                const data = await userModel.findOne({_id:userResult._id}).populate('addressId')
                  
                if(data){
                                   
                return res.send({ reponseCode: 200, responseMessage: 'Profile fetched successfully.', responseResult:data});
            }
        }
        } catch (error) {
            return res.send({ responseCode: 501, responseMessage: "Something went wrong!", responseResult: error.message });
        }


    },
    forgotPassword: async (req, res) => {
        try {
            let query = { $and: [{ email: req.body.email }, { status: { $ne: "DELETE" } }, { userType: 'USER' }], };
            let user = await userModel.findOne(query);
            console.log('====226',user);
            if (!user) {
                return res.send({ reponseCode: 404, responseMessage: 'User not found .', responseResult: result, });
            }
            else {
                let otp = commonFunction.generateOTP();
                let otpExpireTime = Date.now() + 5 * 60 * 1000;
                let subject = "OTP verification for reset password";
                let body = `Your otp for verification: ${otp}`;
                let send = await commonFunction.sendMail(req.body.email, subject, body);
                if (send) {
                    let otpUpdate = await userModel.findOneAndUpdate({
                        _id: user._id
                    },
                        {
                            $set: {
                                otpVerify: false,
                                otp: otp,
                                otpExpireTime: otpExpireTime
                            }
                        },
                        {
                            new: true
                        });
                    if (otpUpdate) {
                        return res.send({ reponseCode: 200, responseMessage: 'Otp send Successfully .', responseResult: otpUpdate, });
                    }
                    
                }


            }


        } catch (error) {
            return res.send({ reponseCode: 500, responseMessage: 'Something went wrong .', responseResult:user });

        }
    },
    editProfile: async (req, res) => {
        try { 
            let query = { _id:req.userId,status: 'ACTIVE', userType: "USER" };
            let user = await userModel.findOne(query);
         
            if (!user) {
                return res.send({ reponseCode: 404, responseMessage: 'User not found .', responseResult: [] });
            } else {
                let query = { $and: [ { email: req.body.email } , { status: { $ne: "DELETE" } }, { userType: 'USER' }] };
                let userCheck = await userModel.findOne(query);
                if (!userCheck) {              
                     let updateUser = await userModel.findByIdAndUpdate({ _id: user._id }, { $set: req.body }, { new: true })
                    if (updateUser) {
                        // let data = {
                        //     userId:updateUser._id,
                        //     email:updateUser.email,
                        //      x:req.body
                        //   }
                        //   let token = jwt.sign(data,'test',{expiresIn:'1h'})                               
                  
                        return res.send({ reponseCode: 200, responseMessage: 'Succesfully updated', responseResult: updateUser }); 
                    }
                }
                else {
                    if (req.body.email == userCheck.email) {
                        return res.send({ reponseCode: 409, responseMessage: 'Email already in use.', responseResult: [] });
                    }
                }
            }
        } catch (error) {
           
            return res.send({ reponseCode: 501, responseMessage: 'Something went wrong', responseResult: error.message });
        }
    },
    resetPassword: async (req, res) => {
        try {
            let query = {$and:  [{ email: req.body.email },{ status: { $ne: "DELETE" } },{userType:'USER'}],};
            let userResult1 = await userModel.findOne(query);
            if(!userResult1){
              return res.send({reponseCode:400,responseMessage:'User not found .',responseResult:[],});
            }
            else{
                    let currentTime =Date.now();
                    if(req.body.otp==userResult1.otp)
                    {
                        if(userResult1.otpExpireTime>=currentTime){
                             if (req.body.newPassword == req.body.confirmNewPassword) {
                            req.body.newPassword=bcrypt.hashSync(req.body.newPassword)
                            let userUpdate =await userModel.findByIdAndUpdate({_id:userResult1._id},{$set:{password:req.body.newPassword,otpVerify:true,}},{new:true})  
                                if (!userUpdate) {
                                    return res.send({reponseCode:500,responseMessage:'Internal server error',result:[]},);
                                } else {
                                    return res.send({reponseCode:200,responseMessage:'Reset password successfully',result:userUpdate},);
                                }
                            }else{
                        return res.send({ responseCode: 400, responseMessage: "newPassword and confirmNewPassword didn't matched.", responseResult: [] })
                            }
                    }else{
                            res.send({reponseCode:410,responseMessage:'OTP is Expired',result:[]},);
                           }
                    }else{
                        res.send({reponseCode:400,responseMessage:'Wrong OTP',result:[]},);
                    }
            }  
        } catch (error) {
            return res.send({responseCode: 501,responseMessage: "Something went wrong!",responseResult: error.message,});
        }
    },
    changePassword:async(req,res)=>{
        try { 
            let query = { email:req.body.email,status: 'ACTIVE', userType: "USER" };
            let userResult1 = await userModel.findOne(query);
            if(!userResult1){
              return res.send({reponseCode:404,responseMessage:'User not found .',responseResult:[],});
            }
            else{
                let passCheck = bcrypt.compareSync(req.body.password,userResult1.password);
                if(passCheck==false){
                  return res.send({reponseCode:401,responseMessage:'Incorrect password.',})
                }
                else{
                    let newPassword = req.body.newPassword;
                    let confirmNewPassword  = req.body.confirmNewPassword
                    if(newPassword!=confirmNewPassword)
                    {
                        res.send({reponseCode:401,responseMessage:'password do not match.',})
                    }
                    else{
                        //req.body.newPassword=bcrypt.hashSync(newPassword)
                    req.body.newPassword=bcrypt.hashSync(newPassword)
                    let userUpdate =await userModel.findByIdAndUpdate({_id:userResult1._id},{$set:{password:req.body.newPassword,}},{new:true})  
                        if (!userUpdate) {
                            return res.send({reponseCode:500,responseMessage:'Internal server error',result:[]},);
                        } else {

                            return res.send({reponseCode:200,responseMessage:'Password changed successfully',result:userUpdate},);
                        }
                    }
                }
            }              
        } catch (error) {
            return res.send({responseCode: 501,responseMessage: "Something went wrong!",responseResult: error.message,});
        }
    },
    allRecords:async(req,res)=>{
        try {
            let data = await userModel.find({document:req.body.document})  
          
          if(!data){
            return res.send({reponseCode:404,responseMessage:'User not found .',responseResult:[],});
          }
          else{
            return res.send({reponseCode:200,responseMessage:'User found successfully',responseResult:data,});
          }

        } catch (error) {
            return res.send({reponseCode:500,responseMessage:'Something went wrong.',responseResult:[],});
            
        }
    },
    showResult: async(req,res)=>{
        try
        {
            var query={status:{$ne:'DELETE'},userType:'USER'};
            if(req.query.search)
            {
                query.$or=[
                    {lastName:{$regex:req.query.search,$options:'i'}},
                    {email:{$regex:req.query.search,$options:'i'}},
                    // {street:{$regex:req.query.search,$options:'i'}},
                    // {city:{$regex:req.query.search,$options:'i'}},
                    // {state:{$regex:req.query.search,$options:'i'}},
                    // {area:{$regex:req.query.search,$options:'i'}},
                    // {country:{$regex:req.query.search,$options:'i'}}
                ]
            }
            let options={
                page:parseInt(req.query.page) ||1,
                limit:parseInt(req.query.limit) ||10,
                sort:{createdAt:-1},
                populate: 'addressId'


            }
            let userData=await userModel.paginate(query,options);
            if(userData.docs.length==0)
            {
                res.send({responseCode:404, responsemessage:'Data Not found',result:[]})
            }
            else{

                res.send({responseCode:200, responsemessage:'Data found successfully',result:userData})
            }

        }
        catch(error){
          
            res.send({responseCode:500, responsemessage:'Something went wrong',result:[]})
        }
    },
    viewUser2: async (req, res) => {
        try {
            if(req.query.fromDate)
            {
                query.createdAt={$gte:req.body.fromDate}
            }
            if(req.query.toDate)
            {
                query.createdAt={$lte:req.body.toDate}
            }
            if(req.query.fromDate && req.query.toDate)
            {
                query.$and[{createdAt:{$gte:req.body.fromDate}},{createdAt:{$lte:req.body.toDate}}]
            }
          let query = { _id:req.userId,status: 'ACTIVE', userType: "USER" };
        
          let usersData = await userModel.findOne(query);
          if(!usersData){
            res.send({responseCode:404,responseResult:[]})
          }else{
            res.send({responseCode:200,responseResult:usersData})
          }
        } catch (error) {
            return res.send({
                responseCode: 501,
                responseMessage: "Something went wrong!",
                responseResult: error.message,
              });
         
        }
      },
// qrCode:async(req,res)=>{

//   try{
//   let qrCodes= await qrCodeGenerate.toString('saurabh Singh Tomar')
//    console.log(qrCodes);
//    if(!qrCodes)
//    {
//        res.send({responseCode:404,responseMessage:'Dtata not found',result:[]})
//    }
//    else{
//     res.send({responseCode:200,responseMessage:'Data found successfully',result:qrCodes})

//    }
  
//     }
// catch(error){
//     res.send({responseCode:501,responseMessage:'Something went wrong',result:[]})
//    }
//  }
upload:async(req,res)=>{
    try {   
const filesUploader = commonFunction.UploadImage('uploaded_file') 
    // req.file is the name of your file in the form above, here 'uploaded_file'
    // req.body will hold the text fields, if there were any 
    console.log(req.file, req.body)
if(!filesUploader)
{
    res.send({responseCode:404,responseMessage:'Retry',result:[]})  
}
else
{
    res.send({responseCode:200,responseMessage:'Uploaded successfully',result:filesUploader})
}
   console.log(req.file, req.body)
    } catch (error) {
        console.log(error)
        res.send({responseCode:501,responseMessage:'Something went wrong',result:[]}) 
    }

},
multiFiles:async(req,res)=>{
    try {
        let image=[];
        // db.query
        for (let index=0;index<req.files.length;index++)
        {
            let files = await commonFunction.UploadImage(req.files[index].path);
            image.push(files)
        }
        if(image.length!=0)
        {
         res.send({responseCode:200,responseMessage:'File uplaoded successfully',result:image})   
        }
        
    } catch (error) {
        res.send({responseCode:501,responseMessage:'Something went wrong',result:error})   
        
    }
}

}

  