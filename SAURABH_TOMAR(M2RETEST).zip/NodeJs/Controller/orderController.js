const inventoryModel = require('../Model/inventoryModel')
//const commonFunction = require("../helper/commonFunction")


module.exports={
    orderSummary:async(req,res)=>{
        try{
           const data= await inventoryModel.findOne({productName:req.body.productName,status:{$ne:'DELETE'},userType:'USER'})
    
    if(data)
       {
        
           if(req.body.productName!=data.productName)
           {
               res.send({responseCode:404,responseMessage:'Product not found ',responseResult:[]})
            }
            else{
            
                // req.body.data=Math.floor(1000 + Math.random() * 1000000);
                let orderData= await inventoryModel(req.body).save()
                quantity= orderData.quantity
    
                req.body.data = orderData.totalquantity-req.body.quantity; 
                let updateData= await inventoryModel(req.body).save()

                res.send({responseCode:200,responseMessage:'Order successfully done ',responseResult:updateData})

          }
     }
    }catch(error){
        console.log(error)
        res.send({responseCode:501,responseMessage:'Something went wrong ',responseResult:[]})

       }

    },
    updateQuantity: async (req, res) => {
        try { 
            let query = {orderId:req.body.orderId ,status: 'ACTIVE', userType: "USER" };
            let user = await inventoryModel.findOne(query);
         
            if (!user) {
                return res.send({ reponseCode: 404, responseMessage: 'Data  not found .', responseResult: [] });
            } else {
                let query = { $and: [ {orderId:req.body.orderId } , { status: { $ne: "DELETE" } }, { userType: 'USER' }] };
                let userCheck = await inventoryModel.findOne(query);
                if (userCheck) {
                  
                     let updateData = await inventoryModel.findByIdAndUpdate({ orderId:req.body.orderId }, { $set: req.body }, { new:true })
                    if (updateData) {
                        return res.send({ reponseCode: 200, responseMessage: 'Succesfully updated', responseResult: updateData}); 
                    }
                }
                else {
                    if (req.body.machineName == userCheck.machineName) {
                        return res.send({ reponseCode: 409, responseMessage: 'Machine already in use.', responseResult: [] });
                    }
                }
            }
        } catch (error) {
            console.log(error)
           
            return res.send({ reponseCode: 501, responseMessage: 'Something went wrong', responseResult: error.message });
            
        }
    },
}