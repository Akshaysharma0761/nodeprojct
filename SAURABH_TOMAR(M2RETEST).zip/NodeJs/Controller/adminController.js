const userModel = require('../Model/userModel')
//const addressModel = require('../Model/addressModel')
const commonFunction = require("../helper/commonFunction")
const auth = require('../middleware/auth')
const bcrypt = require('bcryptjs');

const jwt = require('jsonwebtoken')
module.exports = {
    adminOtpVerify: async (req, res) => {
        try {
           
            let query = {
                $and: [
                    {
                        $or: [
                            { email: req.body.email },
                           
                        ],userType:'ADMIN'
                    },
                    { status: { $ne: "DELETE" } },
                ],
            };
            const dataUser = await userModel.findOne(query)
            if (!dataUser) {
                return res.send({ responseCode: 501, responseMessage: "Something went wrong", result: [] })
            }
            else {
                if (dataUser.otpVerify == true) {
                    return res.send({ responseCode: 200, responseMessage: "Otp verified successfully! ", result: dataUser })
                }
                else {
                    let currentTime = Date.now();
                    if (req.body.otp == dataUser.otp) {
                        console.log('57 ==>', dataUser, currentTime)
                        if (dataUser.otpExpireTime >= currentTime) {
                            let userVerify = await userModel.findByIdAndUpdate({ _id: dataUser._id }, { $set: { otpVerify: true } }, { new: true },)
                            if (userVerify) {
                                return res.send({ responseCode: 200, responseMessage: "Otp is verify", responseResult: dataUser })
                            }
                        }
                        else {
                            return res.send({ responseCode: 401, responseMessage: 'Otp time expire ', responseResult: [] })
                        }
                    }
                    else {
                        return res.send({ responseCode: 400, responseMessage: 'Wrong Otp ', responseResult: [] })
                    }
                }
            }
        }
        catch (error) {
            console.log(error)
            return res.send({ responseCode: 501, responseMessage: "Something went wrong", result: error.message })
        }
    },

    adminResendOTP: async (req, res) => {
        try {
            let query = {
                $and: [
                    {
                        $or: [
                            { email: req.body.email },
                           // {mobileNo:req.body.mobileNo}
                        ],userType:'ADMIN'
                    },
                    { status: { $ne: "DELETE" } },
                ],
            };
            let userResult = await userModel.findOne(query);
            if (!userResult) {
                return res.send({
                    responseCode: 404,
                    responseMessage: "User not found",
                    responseResult: [],

                });
            }
            else {
                console.log('96 ==>', userResult)
                let otp = commonFunction.generateOTP();
                let expireTime = Date.now() + 5 * 60 * 1000;
                let subject = 'Otp for Verify';
                let text = `${otp}`;
                let mailResult = await commonFunction.sendMail(userResult.email, subject, text);
                if (mailResult) {
                    let updateUser = await userModel.findByIdAndUpdate({ _id: userResult._id }, { $set: { otpVerify: false, otp: otp, otpExpireTime: expireTime } }, { new: true })
                    if (updateUser) {
                        return res.send({
                            responseCode: 200,
                            responseMessage: "OTP sent successfully",
                            responseResult: updateUser,
                        })
                    }
                }
            }
        }
        catch (error) {
            console.log('114 ==>', error)
            return res.send({ responseCode: 501, responseMessage: 'something went wrong.', responseResult: error.message })

        }
    },
    adminLogin: async (req, res) => {
        try {
            const userData = await userModel.findOne({
                $and: [{
                     $or: [
                        {email: req.body.email }
                      ]},{userType:"ADMIN"},
                { status: { $ne: "DELETE" }} ]
            })
            
            if (!userData) {
                return res.send({ responseCode: 404, responseMessage: "User not found", result: [] })
            }
            else {
                if (userData.otpVerify == false) {
                    return res.send({ responseCode: 500, responseMessage: "User not verified", result: [] })
                } else {
                  
                    if (req.body.email != userData.email) {
                        return res.send({ responseCode: 401, responseMessage: "Incorrect email id", result: [] })
                    }
                    else {  
                        let passCheck = bcrypt.compareSync(req.body.password, userData.password);
                        if (passCheck == false) {
                            return res.send({ responseCode: 500, responseMessage: "Incorrect password", result: [] })
                        }
                        else {
                            let data = {
                                adminId:userData._id,
                                email:userData.email
                              }
                              let token = jwt.sign(data,'test',{expiresIn:'1h'})                   
                            return res.send({ responseCode: 200, responseMessage: "login successfully", result:data,token})
                        }
                    }
                }
            }
        }
        catch (error) {
            console.log('161 ==>', error)
            return res.send({ responseCode: 501, responseMessage: "Something went wrong", result: error.message })
        }
    },
    adminGetProfile: async (req, res) => {
        try {
            const userResult = await userModel.findOne({
            $and: [{
                 $or: [
                    {email: req.body.email }
                  ]},{userType:"ADMIN"},
            { status: { $ne: "DELETE" }} ]
                })
                
                // let addressResult= await userModel.find({addressId})
                if (!userResult) {
                    return res.send({ reponseCode: 404, responseMessage: 'User not found .', responseResult:[], });
                }
                else {
                    const data = await userModel.findOne({_id:userResult._id}).populate('addressId')
                 
               // const aman=await userModel.find({_id:userResult._id}).populate('addressId')
             
                if(data){
                    // let data = {
                    //     userId:userResult._id,
                    //     email:userResult.email
                    //   }
                    //   let token = jwt.sign(data,'test',{expiresIn:'1h'})                               
                return res.send({ reponseCode: 200, responseMessage: 'Profile fetched successfully.', responseResult:data});
            }
        }
        } catch (error) {
            return res.send({ responseCode: 501, responseMessage: "Something went wrong!", responseResult: error.message });
        }
    },
    adminForgotPassword: async (req, res) => {
        try {
            let query = { $and: [{ email: req.body.email }, { status: { $ne: "DELETE" } }, { userType: 'ADMIN' }], };
            let user = await userModel.findOne(query);
        
            if (!user) {
                return res.send({ reponseCode: 404, responseMessage: 'User not found .', responseResult: [] });
            }
            else {
                let otp = commonFunction.generateOTP();
                let otpExpireTime = Date.now() + 5 * 60 * 1000;
                let subject = "OTP verification for reset password";
                let body = `Your otp for verification: ${otp}`;
                let send = await commonFunction.sendMail(req.body.email, subject, body);
                if (send) {
                    let otpUpdate = await userModel.findOneAndUpdate({
                        _id: user._id
                    },
                        {
                            $set: {
                                otpVerify: false,
                                otp: otp,
                                otpExpireTime: otpExpireTime
                            }
                        },
                        {
                            new: true
                        });
                    if (otpUpdate) {
                        return res.send({ reponseCode: 200, responseMessage: 'Otp send Successfully .', responseResult: otpUpdate, });
                    }
                    
                }


            }


        } catch (error) {
            return res.send({ reponseCode: 500, responseMessage: 'Something went wrong .', responseResult:user });

        }
    },
    adminEditProfile: async (req, res) => {
        try { 
            const user = await userModel.findOne({
                $and: [{
                     $or: [
                        {_id: req.body._id }
                      ]},{userType:"ADMIN"},
                { status: { $ne: "DELETE" }} ]
            })
         
            if (!user) {
                return res.send({ reponseCode: 404, responseMessage: 'User not found .', responseResult: [] });
            } else {
                let query = { $and: [ { email: req.body.email } , { status: { $ne: "DELETE" } }, { userType: 'ADMIN' }] };
                let userCheck = await userModel.findOne(query);
                if (!userCheck) {
                //    let password=bcrypt.hashSync(req.body.password)
                //   const commonFunction=require('.helper/commonfunction');
                 //  async function image()
                     // let userImage= await commonFunction.uploadImage('image')
                   
                  
                    let updateUser = await userModel.findByIdAndUpdate({ _id:user._id }, { $set: req.body }, { new: true })
                    if (updateUser) {
                        // let data = {
                        //     userId:updateUser._id,
                        //     email:updateUser.email,
                        //      x:req.body
                        //   }
                        //   let token = jwt.sign(data,'test',{expiresIn:'1h'})                               
                  
                        return res.send({ reponseCode: 200, responseMessage: 'Succesfully updated', responseResult: updateUser }); 
                    }
                }
                else {
                    if (req.body.email == userCheck.email) {
                        return res.send({ reponseCode: 409, responseMessage: 'Email already in use.', responseResult: [] });
                    }
                }
            }
        } catch (error) {
           
            return res.send({ reponseCode: 501, responseMessage: 'Something went wrong', responseResult: error.message });
            // return res.send(responseCode = 500, responseMessage = "Something went wrong", result = [])
        }
    },
    adminResetPassword: async (req, res) => {
        try {
            let query = {$and:  [{ email: req.body.email },{ status: { $ne: "DELETE" } },{userType:'ADMIN'}],};
            let userResult1 = await userModel.findOne(query);
            if(!userResult1){
              return res.send({reponseCode:404,responseMessage:'User not found .',responseResult:[],});
            }
            else{
                    let currentTime =Date.now();
                    if(req.body.otp==userResult1.otp)
                    {
                        if(userResult1.otpExpireTime>=currentTime){
                             if (req.body.newPassword == req.body.confirmNewPassword) {
                            req.body.newPassword=bcrypt.hashSync(req.body.newPassword)
                            let userUpdate =await userModel.findByIdAndUpdate({_id:userResult1._id},{$set:{password:req.body.newPassword,otpVerify:true,}},{new:true})  
                                if (!userUpdate) {
                                    return res.send({reponseCode:500,responseMessage:'Internal server error',result:[]},);
                                } else {
                                    return res.send({reponseCode:200,responseMessage:'Reset password successfully',result:userUpdate},);
                                }
                            }else{
                        return res.send({ responseCode: 400, responseMessage: "newPassword and confirmNewPassword didn't matched.", responseResult: [] })
                            }
                    }else{
                            res.send({reponseCode:410,responseMessage:'OTP is Expired',result:[]},);
                           }
                    }else{
                        res.send({reponseCode:400,responseMessage:'Wrong OTP',result:[]},);
                    }
            }  
        } catch (error) {
            return res.send({responseCode: 501,responseMessage: "Something went wrong!",responseResult: error.message,});
        }
    },
    adminChangePassword:async(req,res)=>{
        try { 
            let query = { email:req.body.email,status: 'ACTIVE', userType: "ADMIN" };
            let userResult1 = await userModel.findOne(query);
            if(!userResult1){
              return res.send({reponseCode:404,responseMessage:'User not found .',responseResult:[],});
            }
            else{
                let passCheck = bcrypt.compareSync(req.body.password,userResult1.password);
                if(passCheck==false){
                  return res.send({reponseCode:401,responseMessage:'Incorrect password.',})
                }
                else{
                    let newPassword = req.body.newPassword;
                    let confirmNewPassword  = req.body.confirmNewPassword
                    if(newPassword!=confirmNewPassword)
                    {
                        res.send({reponseCode:401,responseMessage:'password do not match.',})
                        
                    }
                    else{
                        //req.body.newPassword=bcrypt.hashSync(newPassword)
                    req.body.newPassword=bcrypt.hashSync(newPassword)
                    let userUpdate =await userModel.findByIdAndUpdate({_id:userResult1._id},{$set:{password:req.body.newPassword,}},{new:true})  
                        if (!userUpdate) {
                            return res.send({reponseCode:500,responseMessage:'Internal server error',result:[]},);
                        } else {

                            return res.send({reponseCode:200,responseMessage:'Password changed successfully',result:userUpdate},);
                        }
                    }
                }
            }              
        } catch (error) {
            return res.send({responseCode: 501,responseMessage: "Something went wrong!",responseResult: error.message,});
        }
    },
  
}