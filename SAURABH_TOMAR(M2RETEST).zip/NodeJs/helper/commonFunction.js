//const req = require('express');
const nodemailer = require('nodemailer');
const userModel = require('../Model/userModel');
const cloudinary=require('cloudinary').v2;
const multer  = require('multer');
const res = require('express/lib/response');

cloudinary.config({ 
  cloud_name: 'dsidwi5nv', 
  api_key: '229522577997292', 
  api_secret: 'Uu7Qd-SKEkR_rloHyDNmVr3lRoE' 
});
module.exports = {
  generateOTP: () => {
    let otp = Math.floor(1000 + Math.random() * 1000000);
      return  otp;
  },
  sendMail: async (email, subject, text) => {
    try {
      var transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: 'pqc-trainee@mobiloitte.com',
          pass: 'Mobiloitte1'
        }
      });
      var mailOptions = {
        from: 'pqc-trainee@mobiloitte.com',
        to:email,
        subject:subject,
        text:text
      };
      return await transporter.sendMail(mailOptions);
    } catch (error) {
      console.log(error)
      return res.send({reponseCode:501,responseMessage:'Something went worng',result:error.message})
    }
  },
  UploadImage:async(image)=>
  {
    try {
      let imageUploadResult=await cloudinary.uploader.upload(image);
      return imageUploadResult.secure_url
    } catch (error) {
      console.log(error.message)
      
    }

  },
  warehouse:async(req,res)=>
  {
    let obj1 = {
      ProductName: "ALMONDS",
     totalQuantity:120
    };
    let obj2 = {
     ProductName: "PEANUT",
     totalQuantity:100
        };
    let obj3 = {
     ProductName: "COCONUT",
     totalQuantity:80
   }
   
  },
  // multipleImageUploader:async(image)=>{
  //   try {
  //     let upload= await cloudinary.uploader.upload(image);
  //     return upload.secure_url;
      
  //   } catch (error) {
  //     res.send({responseCode:501,responseMessage:'Something went wrong',responseResult:error})
      
  //   }
  // }
  generateSerial: (count) => {
    var str=" "+count
    var serial="000"
    var number=serial.substring(0,serial.length-str.length)+str
    console.log('========',"Order-"+number)
    return "Order-"+number

  },
}