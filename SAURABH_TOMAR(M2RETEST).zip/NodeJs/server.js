const express= require('express')
const app=express()
PORT=9000;
//const db = require('./userdb/db')
const swaggerJSDoc = require("swagger-jsdoc");
const swaggerUi = require("swagger-ui-express");

const userRouter=require("./Router/userRouter")
app.use(express.json())
 app.use(express.urlencoded({extended:true}))
app.get('/',(req,res) => {
    res.send("Hello saurabh singh. ")
})
app.post('/',(req,res) => {
    res.send("Hello saurabh singh. ")
})
// const qrCode = require('qrcode')

// {
 
// //   let user = {
// // //     name:''
// // //   }
// qrCode.toString('https://www.google.com/search?q=india%20tourism%20place&tbm=isch&tbs=isz:l&hl=en&sa=X&ved=0CAIQpwVqFwoTCODqvbWxovcCFQAAAAAdAAAAABAC&biw=1513&bih=739#imgrc=CXmUx6SKLN0U6', function (err, url) {
//     console.log(url)
// //   qrCode.toString(user.toString(), function (err, url) {
// //    console.log(url)
//   })
  
// }


const db=require('./userdb/db')
app.use("/user",userRouter)
app.use("/admin",userRouter)
app.use("/machine",userRouter)
app.use("/order",userRouter)


app.use('/static',require('./Router/staticRouter'))

const swaggerDefinition = {
    info: {
      title: "compliance-node",
      version: "1.0.0",
      description: "Swagger API Docs",
    },
    host: `localhost:${PORT}`,
    basePath: "/",
   };
   const options = {
    swaggerDefinition: swaggerDefinition,
    apis: ["./Router/*.js"],
   };
   const swaggerSpec = swaggerJSDoc(options);
   app.get("/swagger.json", (req, res) => {
    res.setHeader("Content-Type", "application/json");
    res.send(swaggerSpec);
   });
   
   /** Server Listen **/
   app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));
 

app.listen(PORT,(err,result) => {
    if(err)
{
    console.log('internal error',err)
}
else{
    console.log('server is listening',PORT)
}
});
// const commonFunction=require('./helper/commonFunction');
// async function image(){
//     console.log(await commonFunction.uploadImage('data:image/jpeg;base64,/9j
// }
// image()