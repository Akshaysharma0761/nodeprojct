const mongoose =require('mongoose');
mongoose.connect('mongodb+srv://admin:admin@cluster0.xnmxd.mongodb.net/myFirstDatabase?retryWrites=true&w=majority',
(err,result)=>{
    if(err)
    {
        console.log('Db connection error',err)
    }
    else{
        console.log('Db connected successfully.')

    }
});