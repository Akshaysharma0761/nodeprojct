const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const bcrypt = require("bcryptjs");
const mongoosePaginate= require('mongoose-paginate')

const userSchema = new Schema({
  
    firstName: {

        type: String
    },

    lastName: {
        type: String
    },

    email: {
        type: String
   
    },
    password: {
        type: String
   


    },
    mobileNo: {
        type: Number


    },
    countryCode:
    {
        type:String
    },
    address:{
        type:String
    },
    dateOfBirth:
    {
        type:Date
    },

    
    otp: {

        type: Number

    },
    otpVerify: {

        type: Boolean,
        default:false

    },

    otpExpireTime: {

        type: Number

    },
    addressId:{
      type:Schema.Types.ObjectId,
      ref:'address'
    },
    userType: {

      type: String,

      enum: ["ADMIN", "USER"], default: "USER"

  },
  status:
  {
    type:String,
    enum:["ACTIVE","DELETE","BLOCK"],
    default:"ACTIVE",
  },
    
},{ timestamps: true })

userSchema.plugin(mongoosePaginate)
// module.exports = mongoose.model("users", keys)
let userModel = mongoose.model("user", userSchema);
module.exports = userModel;
 
userModel.findOne(
 { status: { $ne: "DELETE" }, userType: "ADMIN" },
 (userErr, userRes) => {
   if (userErr) {
   } else if (userRes) {
     
     console.log("Default admin already exist");
   } else {
     let admin = {
       firstName: "Saurav",
       lastName: "Tomar",
       email: "admin@indicchain.com",
       mobileNumber: 1234567890,
       password: bcrypt.hashSync("12345"),
       userType: "ADMIN",
       otpVerify: true,
     };
     userModel(admin).save((saveErr, saveAdmin) => {
       if (saveErr) {
       } else {
         console.log("Default admin created");
       }
     });
   }
 });
