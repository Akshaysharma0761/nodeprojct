 const mongoose = require('mongoose');
const Schema = mongoose.Schema;
//const bcrypt = require("bcryptjs");
const mongoosePaginate= require('mongoose-paginate');
//const { stringify } = require('nodemon/lib/utils');

const machine = new Schema({
  
    machineName: {

        type: String
    },

    serialNumber:
    {
    type:String,
},
capacity:
{
type:String,
},
    url: {
        type: String
    },
    images:{
        type:[String]
    },
    nozzels: {
        type:Number,
       
    },
    type: {
        type:String,
       
    },
    userType: {
        type: String,
        enum: ["ADMIN", "USER"], default: "ADMIN",
    },
    status:
    {
      type:String,
      enum:["ACTIVE","DELETE","BLOCK"],
      default:"ACTIVE",
    },
      
  },{ timestamps: true })
  machine.plugin(mongoosePaginate)
let machineModel = mongoose.model("machine", machine)
module.exports = machineModel;
