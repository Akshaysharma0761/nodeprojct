const mongoose = require('mongoose');
const mongoosePaginate = require('mongoose-paginate');
const Schema = mongoose.Schema;
const products = new Schema({
    productName:
    {
type:String
    },
    quantity:
    {
      type:Number
    },
    orderId:
    {
    type:Number
    },
  
 
    userType: {
        type: String,
        enum: ["ADMIN", "USER"], default: "USER",
    },
    status:
    {
      type:String,
      enum:["ACTIVE","DELETE","BLOCK"],
      default:"ACTIVE",
    },
      
  },{ timestamps: true })
//  inventoryModel.plugin(mongoosePaginate);
  let inventoryModel = mongoose.model("order",products);
  module.exports = inventoryModel;
   
